import os as _os


VERSION = "1.0.4.10"

# Remote runtimes are extracted outside the original AScript project. Resolve
# resources from this package instead of R.ui/R.res so downloaded HTML, fonts,
# images, and other assets are used together with the downloaded Python code.
PROJECT_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))


def resource_path(*child_paths):
    return _os.path.join(PROJECT_ROOT, "res", *child_paths)


def ui_resource(*child_paths):
    return resource_path("ui", *child_paths)


def image_resource(*child_paths):
    return resource_path("img", *child_paths)

SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
SCREEN_CENTER_X = 640
SCREEN_CENTER_Y = 360

# 本地游戏位置
WALK_BUTTON_CENTER_X = 209
WALK_BUTTON_CENTER_Y = 553

action_button_position = {
    "小技能": (896,644),
    "大招": (982,643),
    "魔灵技": (1112,643),
    "近战攻击": (1115,504),
    "远程攻击": (976,528),
    "跳跃": (1013,421),
    "闪避": (1125,366),
    "换弹": (895,529),
    "锁敌": (1214, 645),
    "下蹲": (57,590),
}

# 交互文本区域
interaction_text_rect = {
    "单行":[653,324,944,385],
    "多行":[667,296,948,547]
}

# 云游戏位置
CLOUD_WALK_BUTTON_CENTER_X = 208
CLOUD_WALK_BUTTON_CENTER_Y = 551

cloud_action_button_position = {
    "小技能": (858,643),
    "大招": (943,644),
    "魔灵技": (1073,643),
    "近战攻击": (1080,504),
    "远程攻击": (938,527),
    "跳跃": (976,422),
    "闪避": (1090,366),
    "换弹": (858,529),
    "锁敌": (1172,620),
    "下蹲": (86,591),
    "行走": (99,572),
}

# 交互文本区域
cloud_interaction_text_rect = {
    "单行":[673,331,945,380],
    "多行":[670,277,945,555]
}

skill_time = {
    "小技能":10,
    "小技能_释放时间":0,
    "大招":10,
    "大招_释放时间":0,
    "魔灵技":15,
    "魔灵技_释放时间":0
}
